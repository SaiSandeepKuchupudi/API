﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Server
{
    public static class Constants
    {
        public const string Issuer = Audiance;
        public const string Audiance = "https://localhost:44376/";
        public const string secret = "not_too_short_secret_otherwise_it_might_error";

        public static unsafe char* Secret { get; internal set; }
    }
}