using Basics.AuthorizationRequirements;
using IdentityExample.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.CodeAnalysis.FlowAnalysis;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Security.Claims;

namespace Basics
{
    public class Startup
    {
        private object confg;

        public object ConfigureServices(IServiceCollection services) {
            services.AddDbContext<AppDbContext>(config =>
            {
                config.UseInMemoryDatabase("Memory");
            });

            
            // AddIdentity registers the services 
            services.AddIdentity<IdentityUser, IdentityRole>()
                .AddEntityFrameworkStores<AppDbContext>()
                .AddDefaultTokenProviders();
            //services.AddAuthentication("CookieAuth")
            //          .AddCookie("CookieAuth", config =>
            //        {
            //      config.Cookie.Name = "Grandms.Cookie";
            //    config.LoginPath = "/Home/Authenticate";
            //  });
            services.AddAuthorization(config =>
            {
                var defaultAuthBuilder = new AuthorizationPolicyBuilder();
                var defaultAuthPolicy = defaultAuthBuilder
                .RequireAuthenticatedUser()
                .RequireClaim(ClaimTypes.DateOfBirth)
                .Build();
                
                config.DefaultPolicy = defaultAuthPolicy;
                //    config.AddPolicy("Claim.DOB", policyBuilder =>
                //    {
                //        policyBuilder.RequireClaim(ClaimTypes.DateOfBirth);
                //    });

                //});
                config.AddPolicy("Admin", policyBuilder => policyBuilder.RequireClaim(ClaimTypes.Role, "Admin"));

                config.AddPolicy("Claim.DOB", policyBuilder =>
                {
                    policyBuilder.RequireCustomClaim(ClaimTypes.DateOfBirth);
                });

            });
            services.AddScoped<IAuthorizationHandler, CustomRequireClaimHandler>();
            services.AddControllersWithViews();

            _ = services.AddRazorPages()
            .AddRazorPagesOptions(confg =>
            {
                confg.Conventions.AuthorizePage("/Razor/Secured");
                confg.Conventions.AuthorizePage("/Razor/Policy", "Admin");
                confg.Conventions.AuthorizeFolder("/RazorSecured");
                confg.Conventions.AllowAnonymousToPage("/RazorSecured/Anno");
            });
        }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
                endpoints.MapRazorPages();
            });
        }
    }
}
